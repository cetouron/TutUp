export default [
    {
    idmess: 1, 
    content: "Bonjour, êtes vous dispo ?", 
    user: 'me', 
    receveur: 'Louis'
    },
    {
    idmess: 2, 
    content: "Bonjour, oui", 
    user: 'Louis', 
    receveur: 'me'
    },
    {
    idmess: 3, 
    content: "blabla", 
    user: 'Marc', 
    receveur: 'me'
    },
    {
    idmess: 4, 
    content: "Pour quelles matières ?", 
    user: 'Louis', 
    receveur: 'me'
    },
    {
    idmess: 5, 
    content: "Français", 
    user: 'me', 
    receveur: 'Louis'
    },
    {
    idmess: 6, 
    content: "Et Anglais éventuellement", 
    user: 'me', 
    receveur: 'Marc'
    }
]
