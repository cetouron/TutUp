<template>
  <v-container>     
        <ProfilTuteur />
 

  </v-container>
</template>

<script>
import ProfilTuteur from '@/components/profilTuteur/ProfilTuteur.vue'


export default {
  components: {
    ProfilTuteur
  }
}
</script>