<template>
  <v-container>     
        <Register />
 

  </v-container>
</template>

<script>
import Register from '@/components/register/Register.vue'

export default {
  components: {
    Register
  }
}
</script>
