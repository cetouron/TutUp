<template>
  <v-container>
 
        <Formulaire />

  </v-container>
</template>

<script>
import Formulaire from '@/components/connexion/Formulaire.vue'

export default {
  components: {
    Formulaire
  }
}
</script>
