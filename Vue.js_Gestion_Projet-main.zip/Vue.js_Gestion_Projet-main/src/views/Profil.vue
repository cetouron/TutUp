<template>
  <v-container>     
        <Profil />
 

  </v-container>
</template>

<script>
import Profil from '@/components/profil/Profil.vue'


export default {
  components: {
    Profil
  }
}
</script>
