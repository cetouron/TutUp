<template>
  <v-container>     
        <ProfilEleve />
 

  </v-container>
</template>

<script>
import ProfilEleve from '@/components/profilEleve/ProfilEleve.vue'


export default {
  components: {
    ProfilEleve
  }
}
</script>