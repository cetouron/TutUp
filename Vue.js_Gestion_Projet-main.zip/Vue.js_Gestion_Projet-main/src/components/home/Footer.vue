<template>
  <v-footer
      absolute
      class="font-weight-medium"
    >
      <v-col
        class="text-center"
        cols="12"
      >
        &copy; {{ new Date().getFullYear() }} — <strong>Tut'Up</strong>
      </v-col>
    </v-footer>
</template>
